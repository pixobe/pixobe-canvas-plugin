<?php
/***
 *
 * Block render
 *
 * @since 1.1
 * @package pixobe-canva
 */
?>

<article>
	<pixobe-canva></pixobe-canva>
</article>
