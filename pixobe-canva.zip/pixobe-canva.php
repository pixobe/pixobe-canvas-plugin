<?php
/**
 *
 * @link              https://pixobe.com/wp-plugin/canva
 * @since             1.0.0
 * @package           Pixobe_Canva
 *
 * @wordpress-plugin
 * Plugin Name:       Pixobe Canva
 * Plugin URI:        https://pixobe.com/wp-plugin/canva
 * Description:       Build Canvas by Drag and drop images, adjust layouts,add text and export as JPGs, PDF etc.
 * Requires at least: 5.9
 * Requires PHP:      7.0
 * Version:           1.0.0
 * Author:            Pixobe
 * Author URI:        https://pixobe.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       pixobe-canva
 */

// if this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly


// auto loader.
require_once trailingslashit( dirname( __FILE__ ) ) . 'autoloader.php';

use Plugin\PixobeCanva\Inc\{Pixobe_Canva_Plugin};

/**
 * Undocumented function
 */
function plugin_pixobe_canva() {
	return Pixobe_Canva_Plugin::get_instance();
}
plugin_pixobe_canva();
