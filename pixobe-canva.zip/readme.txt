=== Pixobe Canva ===
Contributors:      Pixobe
Tags:              canvas, Drag anddrop images,canva
Tested up to:      6.1.1
Stable tag:        1.0.0
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Example block scaffolded with Create Block tool.

== Description ==

Drag and drop images, adjust layouts,add text and export as JPGs, PDF etc.

== Installation ==

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==


== Changelog ==


== Arbitrary section ==
